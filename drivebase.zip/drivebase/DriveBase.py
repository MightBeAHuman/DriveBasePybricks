from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorDistanceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task
import umath as math

hub = PrimeHub()

class DriveBase:
    def __init__(self, hub: PrimeHub, port_left: Port, port_right: Port, wheel_diameter: int, axle_track: int, negative_direction: bool = False, action_motors: dict = None, sensors: dict = None, Kp: int = 0, Tn: int = 0, Tv: int = 0):
        """
        An interface used to abstract motor controlling into easy to use functions. Supports gyro stabilization using PID.
        :param motor_left: Left motor
        :param motor_right: Right motor
        :param wheel_diameter: Average wheel diameter
        :param axle_track: Horizontal distance between the middle of both wheels
        :param negative_direction: Whether the main direction is negative
        :param action_motors: A dictionary containing names as keys and motors as values. These motors will be stored as class vars by their name.
        :param sensors: A dictionary containing names as keys and sensors as values. These sensors will be stored as class vars by their name.
        :param Kp: Proportional constant for PID Gyro Control
        :param Tn: Kp / Tn equals the integral constant for PID Gyro Control (Tn is easier to tune intuitively)
        :param Tv: Kp * Tv equals the derivative constant for PID Gyro Control (Tv is easier to tune intuitively)
        """

        self.hub = hub
        self.imu = self.hub.imu
        self.imu.reset_heading(0)
        self.ml = Motor(port_left, Direction.COUNTERCLOCKWISE)
        self.mr = Motor(port_right)
        self.wheel_diameter = wheel_diameter
        self.axle_track = axle_track
        self.negative_direction = negative_direction
        self.action_motors = action_motors if type(action_motors) == dict else {}
        print(action_motors)
        self.sensors = sensors if type(sensors) == dict else {}
        self.Kp, self.Tn, self.Tv = Kp, Tn, Tv

        for key, value in self.action_motors.items(): setattr(self, key, value)
        for key, value in self.sensors.items(): setattr(self, key, value)

    async def calc_acceleration(self):
        # TODO: dynamic acceleration for improved accuracy
        pass

    async def arc(self, radius, angle, speed=200, clockwise: bool = True):
        """
        Move in an arc-like motion to a given arc angle by a given radius. Supports async movement.
        :param radius: Arc radius towards the inner wheel.
        :param angle: Final angle from starting position.
        :param speed: The robots average speed along the midpoint between both wheels.
        :param clockwise: Wether the robot should run the arc clockwise.
        """
        if angle < 0: angle = -angle; speed=-speed
    
        cl, cr = radius / (radius + self.axle_track / 2), (radius + self.axle_track) / (radius + self.axle_track / 2)
        if not clockwise: cl, cr = cr, cl
        
        sl, sr = speed * cl, speed * cr
        d = 2 * (radius + self.axle_track / 2) * math.pi * (angle / 360)
        dl, dr = cl*d/(self.wheel_diameter * math.pi)*360, cr*d/(self.wheel_diameter * math.pi)*360
        
        self.ml.run_angle(sl, (dl))
        await self.mr.run_angle(sr, (dr))

    async def yaw(self, deg: int = 0, max_velocity: int = 300, min_velocity: int = 20):
        deg = deg % 360
        time_limit = 3000
        s = StopWatch()
        start = s.time()

        while True:
            current_yaw = (self.imu.heading()) % 360
            if current_yaw < 0: current_yaw = 360 - current_yaw
            difference = deg - current_yaw
    
            if abs(difference) < 0.1:
                self.ml.stop()
                self.mr.stop()
                break
    
            if s.time() - start > time_limit:
                print("Timeout")
                break

            if abs(difference) > 180:
                difference = (360 - abs(difference)) * -1 * (difference/abs(difference))
            direction = 1 if difference >= 0 else -1
    
            # higher values = higher average speed
            speed_potency = 3
            velocity = round(min_velocity + (max_velocity - min_velocity) * (abs(difference) / 180) ** (1 / speed_potency))
            self.ml.run(velocity * direction)
            self.mr.run(-velocity * direction)
    
        self.ml.stop()
        self.mr.stop()
    
    async def straight(self, distance: int, velocity: int, gyro_support: bool = False):
        if not gyro_support:
            d = distance * 360 / self.wheel_diameter
            self.ml.run_angle(velocity, d)
            await self.mr.run_angle(velocity, d)
            return
        # TODO: gyro support + DynAcc
        pass
    
    async def run(self, motor_name: str, degrees: int, velocity: int = 300):
        await getattr(self, motor_name).run_angle(velocity, degrees)
    
    async def start_db(self, velocity: int):
        velocity *= 360 / (math.pi * self.wheel_diameter)
        self.ml.run(velocity)
        self.mr.run(velocity)
    
    async def stop_db(self):
        self.ml.stop()
        self.mr.stop()
    
    # async def elliptical_arc():
        # pass
    
    async def steer(self, velocity: int, steering: int):
        steering = max(-100, min(100, steering))
        sr = -steering / 100 if steering < 0 else 1
        sl = steering / 100 if steering > 0 else 1
        self.ml.run(velocity * sl)
        self.mr.run(velocity * sr)
    
    async def color_recognition():
        pass
    
    async def settings():
        # default_speed, acceleration, deceleration, PID, use_gyro
        pass

    async def action_arc(self, radius: int, angle: int, velocity: int, action_name: str, mm_per_rotation: int, starting_angle: int = 0, backwards: bool = False):
        """
        Moves any forklift like structure in an arc like motion
        
        :param radius: The radius of the arc in mm
        :param angle: The final angle of the arc motion
        :param mm_per_rotation: The amount of mm per rotation of the action motor the forklift moves
        :param velocity: velocity in deg/sec
        :param starting_angle: The angle the arc motion starts at
        """
        # TODO: improvements

        ma = getattr(self, action_name)
        if ma is None: raise AttributeError(f"Motor {motor_name} does not exist!") 
        angle %= 360
        starting_angle %= 360
        d_angle = (angle - starting_angle) % 360
        rad_angle = math.radians(d_angle)
        rad_starting_angle = math.radians(starting_angle)
        t_max = 1000 * d_angle / velocity

        backwards = -1 if backwards else 1

        s = StopWatch()
        while (t := s.time()) < t_max:
            phi = (rad_starting_angle + math.radians(90) + t * rad_angle / t_max) % (math.radians(360))
            vx, vy = radius * math.radians(velocity) * math.cos(phi), radius * math.radians(velocity) * math.sin(phi)
            # print(math.sqrt(vx ** 2 + vy ** 2))
            vx *= backwards
            vy *= (360 / mm_per_rotation)
            ma.run(vy)
            await self.start_db(vx)

        ma.stop()
        await self.stop_db()

    # PID
    def sigmoid(self, x):
        return 1 / (1 + math.exp(-x)

async def main(db):
    await db.run("mb", 360)
    await db.action_arc(180, 95, 30, "mb", 30, 12, True)

if __name__ == "__main__":
    # mr, ml = Motor(Port.A), Motor(Port.E, positive_direction=Direction.COUNTERCLOCKWISE)
    # run_task(main())
    db = DriveBase(PrimeHub(), Port.F, Port.B, 57, 113, action_motors={"mb": Motor(Port.A, Direction.COUNTERCLOCKWISE), "mf": Motor(Port.C, Direction.COUNTERCLOCKWISE)})
    print(dir(db))
    run_task(main(db))